

// let url = 'http://192.168.1.38:9000'
// let url = 'http://192.168.29.78:9000'
// let url = 'http://localhost:9000'
let url = 'http://192.168.29.78:9000'
// let url = 'http://localhost:9000'
// let url = 'http://192.168.29.78:9000'

exports.baseURL = url