import './footer.css'
export default function Footer() {
    return(
           <footer className="footer-bg-pic">
        <div className="ocean">
  <div className="wave"></div>
  <div className="wave"></div>
  <div className="wave"></div>
</div>
          </footer>
    )
}